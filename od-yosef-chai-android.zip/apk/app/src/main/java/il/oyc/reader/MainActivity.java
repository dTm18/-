package il.oyc.reader;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);           // localStorage: theme, font size, last position
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);                     // the app has its own font-size control

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // fonts are loaded over https from a page served on file://
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        // keep every link inside the WebView
        web.setWebViewClient(new WebViewClient());

        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    @Override
    public void onBackPressed() {
        // let the page handle "back" first (reader -> menu), then exit
        web.evaluateJavascript(
            "(function(){ if (typeof goBack === 'function' && document.getElementById('backbtn')" +
            " && !document.getElementById('backbtn').classList.contains('hidden')) { goBack(); return 'handled'; }" +
            " return 'exit'; })()",
            value -> {
                if (value != null && value.contains("exit")) {
                    finish();
                }
            });
    }
}
